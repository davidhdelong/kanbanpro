from asgiref.wsgi import WsgiToAsgi
from app import create_app
from app.realtime import sio
import socketio

flask_app = create_app()
application = WsgiToAsgi(flask_app)

asgi_app = socketio.ASGIApp(sio, application)
