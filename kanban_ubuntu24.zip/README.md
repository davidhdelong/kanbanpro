# Kanban Pro (Flask + SQLite)

A production-ready Trello-style project management app built with Flask, Flask-SQLAlchemy, Flask-Login, bcrypt, and SQLite.

## Features
- Multi-user system with first user auto-admin
- Boards → Lists → Cards with drag-and-drop ordering
- Labels, search, and file attachments
- Search filters by board, label, and due status
- Board roles (owner/admin/member/viewer)
- Due dates + calendar view
- Board ownership + invites by email token
- Password reset via email code + token
- Admin panel for users, boards, SMTP, email logs, and stats
- AI digest settings for Anthropic-compatible API and daily digest cron
- Activity logs (board + admin)
- SMTP-configurable email delivery with DB logs
- Cron-triggered reminders endpoint with token protection
- Responsive Bootstrap 5 UI with light/dark toggle and prefers-color-scheme support

## Quick Start
1. Create a virtual environment and install dependencies:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Configure environment:
   ```bash
   cp .env.example .env
   ```
   Update `SECRET_KEY`, `APP_URL`, and SMTP values. Set `REMINDER_TOKEN` for the cron endpoint.
3. Run the app:
   ```bash
   python app.py
   ```
4. Open `http://127.0.0.1:5000`.

## Notes
- The SQLite database is stored in the Flask instance directory and created automatically on first run.
- The first registered user becomes an admin automatically.
- The cron endpoint is: `GET /reminders?token=YOUR_TOKEN`.
- Digest endpoint: `GET /digests?token=YOUR_DIGEST_TOKEN`.
- Admins can set a local timezone in the Admin → Timezone tab.
- Admins can configure reminders and backups in Admin → Maintenance (updates the `server` user crontab).
- Admins can run a backup immediately and view backup logs.
- Health endpoint: `GET /health`.
- WebSocket health endpoint: `GET /health/ws`.

## Deployment
### systemd
See `deploy/kanban.service`. Update paths and user if needed, then:
```bash
sudo cp deploy/kanban.service /etc/systemd/system/kanban.service
sudo systemctl daemon-reload
sudo systemctl enable --now kanban
```

### Health checks
Optional systemd timer to hit `/health` every 5 minutes:
```bash
sudo cp deploy/kanban-healthcheck.service /etc/systemd/system/kanban-healthcheck.service
sudo cp deploy/kanban-healthcheck.timer /etc/systemd/system/kanban-healthcheck.timer
sudo systemctl daemon-reload
sudo systemctl enable --now kanban-healthcheck.timer
```

### Cron
The Admin → Maintenance tab updates the `server` user crontab with reminders and backups schedules.

### Nginx
See `deploy/nginx.conf` and adjust `server_name`.

## Project Structure
- `app.py`
- `app/__init__.py`
- `app/models.py`
- `app/auth/routes.py`
- `app/boards/routes.py`
- `app/admin/routes.py`
- `app/main/routes.py`
- `app/templates/`
- `app/static/`
- `deploy/`

## Production Tips
- Use a strong `SECRET_KEY`.
- Configure a real SMTP relay.
- Run behind Nginx with TLS (e.g., Let’s Encrypt).
- Use a process manager (systemd or gunicorn if desired).
- Realtime updates use Socket.IO over ASGI (Uvicorn) with true WebSockets.
