#!/usr/bin/env bash
set -euo pipefail

APP_DIR=${APP_DIR:-/opt/kanban}
APP_USER=${APP_USER:-kanban}
APP_GROUP=${APP_GROUP:-kanban}

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root (sudo)." >&2
  exit 1
fi

apt-get update
apt-get install -y python3 python3-venv python3-pip

if ! id "$APP_USER" >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$APP_USER"
fi

mkdir -p "$APP_DIR"
rsync -a --delete --exclude '.venv' --exclude 'instance' --exclude 'backups' ./ "$APP_DIR/"

chown -R "$APP_USER":"$APP_GROUP" "$APP_DIR"

if [ ! -d "$APP_DIR/.venv" ]; then
  python3 -m venv "$APP_DIR/.venv"
fi

"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

mkdir -p "$APP_DIR/instance/uploads"
chown -R "$APP_USER":"$APP_GROUP" "$APP_DIR/instance"

if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  SECRET_KEY=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)
  REMINDER_TOKEN=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(16))
PY
)
  DIGEST_TOKEN=$(python3 - <<'PY'
import secrets
print(secrets.token_hex(16))
PY
)
  sed -i "s/^SECRET_KEY=.*/SECRET_KEY=$SECRET_KEY/" "$APP_DIR/.env"
  sed -i "s/^REMINDER_TOKEN=.*/REMINDER_TOKEN=$REMINDER_TOKEN/" "$APP_DIR/.env"
  sed -i "s/^DIGEST_TOKEN=.*/DIGEST_TOKEN=$DIGEST_TOKEN/" "$APP_DIR/.env"
fi

cat > /etc/systemd/system/kanban.service <<SERVICE
[Unit]
Description=Kanban Pro Flask App
After=network.target

[Service]
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/uvicorn asgi:asgi_app --host 0.0.0.0 --port 5000
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable --now kanban

systemctl status kanban --no-pager

echo "\nKanban is running on port 5000."
