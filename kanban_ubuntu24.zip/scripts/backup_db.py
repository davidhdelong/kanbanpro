import argparse
import os
import shutil
from datetime import datetime, timedelta


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="/home/server/instance/app.db")
    parser.add_argument("--dest", default="/home/server/backups")
    parser.add_argument("--retention-days", type=int, default=7)
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.dest, exist_ok=True)

    if not os.path.exists(args.db):
        raise SystemExit(f"Database not found: {args.db}")

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(args.dest, f"app_{timestamp}.db")
    shutil.copy2(args.db, backup_path)

    cutoff = datetime.utcnow() - timedelta(days=args.retention_days)
    for name in os.listdir(args.dest):
        if not name.startswith("app_") or not name.endswith(".db"):
            continue
        path = os.path.join(args.dest, name)
        mtime = datetime.utcfromtimestamp(os.path.getmtime(path))
        if mtime < cutoff:
            try:
                os.remove(path)
            except OSError:
                pass


if __name__ == "__main__":
    main()
