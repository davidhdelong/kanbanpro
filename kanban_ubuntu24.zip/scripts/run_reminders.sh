#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="/home/server/.env"
if [ -f "$ENV_FILE" ]; then
  # shellcheck disable=SC1090
  source "$ENV_FILE"
fi

APP_URL=${APP_URL:-"http://127.0.0.1:5000"}
REMINDER_TOKEN=${REMINDER_TOKEN:-""}

if [ -z "$REMINDER_TOKEN" ]; then
  echo "REMINDER_TOKEN not set" >&2
  exit 1
fi

curl -fsS "${APP_URL}/reminders?token=${REMINDER_TOKEN}" >/dev/null
