from datetime import datetime, timedelta
from app import create_app
from app import db
from app.models import InviteToken, ResetToken, EmailLog, BackupLog, Setting


def main():
    app = create_app()
    with app.app_context():
        retention_value = Setting.get("cleanup_retention_days", "30")
        try:
            retention_days = int(retention_value)
        except (TypeError, ValueError):
            retention_days = 30

        now = datetime.utcnow()
        cutoff = now - timedelta(days=retention_days)

        InviteToken.query.filter(
            (InviteToken.expires_at < now) | (InviteToken.accepted.is_(True))
        ).delete(synchronize_session=False)
        ResetToken.query.filter(
            (ResetToken.expires_at < now) | (ResetToken.used.is_(True))
        ).delete(synchronize_session=False)
        EmailLog.query.filter(EmailLog.created_at < cutoff).delete(synchronize_session=False)
        BackupLog.query.filter(BackupLog.created_at < cutoff).delete(synchronize_session=False)

        db.session.commit()


if __name__ == "__main__":
    main()
