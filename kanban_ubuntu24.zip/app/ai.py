import json
import requests
from flask import current_app
from .models import Setting


def get_ai_config():
    return {
        "enabled": Setting.get("ai_enabled", "false") == "true",
        "api_key": Setting.get("ai_api_key", ""),
        "base_url": Setting.get("ai_base_url", "https://api.anthropic.com"),
        "model": Setting.get("ai_model", "claude-3-haiku-20240307"),
        "ignore_ssl": Setting.get("ai_ignore_ssl", "false") == "true",
    }


def generate_digest(prompt):
    config = get_ai_config()
    if not config["enabled"] or not config["api_key"]:
        return None, "AI not configured"

    url = config["base_url"].rstrip("/") + "/v1/messages"
    headers = {
        "x-api-key": config["api_key"],
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": config["model"],
        "max_tokens": 600,
        "temperature": 0.3,
        "messages": [{"role": "user", "content": prompt}],
    }

    try:
        resp = requests.post(
            url,
            headers=headers,
            data=json.dumps(payload),
            timeout=20,
            verify=not config["ignore_ssl"],
        )
        if resp.status_code >= 400:
            return None, f"AI error: {resp.status_code}"
        data = resp.json()
        content = data.get("content", [])
        if content and isinstance(content, list) and content[0].get("text"):
            return content[0]["text"], None
        return None, "AI response missing content"
    except Exception as exc:  # noqa: BLE001
        return None, str(exc)


def test_connection():
    prompt = "Reply with a single line: OK"
    return generate_digest(prompt)
