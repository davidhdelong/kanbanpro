import smtplib
from email.message import EmailMessage
from flask import current_app
from .models import EmailLog, Setting
from . import db


def _smtp_bool(value, default=False):
    if value is None:
        return default
    return str(value).lower() in ("1", "true", "yes", "on")


def get_smtp_config():
    host = Setting.get("smtp_host", current_app.config.get("SMTP_HOST"))
    port = int(Setting.get("smtp_port", current_app.config.get("SMTP_PORT")))
    user = Setting.get("smtp_user", current_app.config.get("SMTP_USER"))
    password = Setting.get("smtp_pass", current_app.config.get("SMTP_PASS"))
    use_tls = _smtp_bool(Setting.get("smtp_tls", current_app.config.get("SMTP_TLS")), True)
    from_email = Setting.get("smtp_from", current_app.config.get("SMTP_FROM"))
    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "use_tls": use_tls,
        "from_email": from_email,
    }


def send_email(to_email, subject, body):
    config = get_smtp_config()
    status = "sent"
    error = None
    try:
        if not config["host"]:
            raise RuntimeError("SMTP host not configured")
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = config["from_email"]
        msg["To"] = to_email
        msg.set_content(body)

        with smtplib.SMTP(config["host"], config["port"], timeout=15) as server:
            if config["use_tls"]:
                server.starttls()
            if config["user"]:
                server.login(config["user"], config["password"] or "")
            server.send_message(msg)
    except Exception as exc:  # noqa: BLE001
        status = "failed"
        error = str(exc)

    log = EmailLog(to_email=to_email, subject=subject, body=body, status=status, error=error)
    db.session.add(log)
    db.session.commit()

    return status == "sent", error
