from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from sqlalchemy import or_
from flask_login import login_required, current_user
from .. import db
from ..models import Board, BoardMember, Card, NotificationPreference, User, Label, List
from ..utils import is_board_member, get_utc_window
from ..email import send_email
from ..ai import generate_digest
from ..realtime import active_connections


main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    return render_template("main/index.html")


@main_bp.route("/health")
def health():
    return jsonify({"status": "ok"}), 200


@main_bp.route("/health/ws")
def ws_health():
    return jsonify({"status": "ok", "ws": True, "active_connections": active_connections}), 200


@main_bp.route("/dashboard")
@login_required
def dashboard():
    owned = Board.query.filter_by(owner_id=current_user.id).all()
    member_board_ids = [m.board_id for m in current_user.board_memberships]
    member_boards = Board.query.filter(Board.id.in_(member_board_ids)).all() if member_board_ids else []
    cards = Card.query.filter(Card.due_date.isnot(None)).all()
    now = datetime.utcnow()
    upcoming = []
    overdue = []
    for card in cards:
        if is_board_member(card.list.board, current_user):
            if card.due_date and card.due_date < now:
                overdue.append({"card": card, "status": "overdue"})
            elif card.due_date and card.due_date <= now + timedelta(days=7):
                status = "due" if card.due_date <= now + timedelta(days=1) else "upcoming"
                upcoming.append({"card": card, "status": status})
    upcoming = sorted(upcoming, key=lambda c: c["card"].due_date)[:5]
    overdue = sorted(overdue, key=lambda c: c["card"].due_date, reverse=True)[:5]

    return render_template(
        "main/dashboard.html",
        owned=owned,
        member_boards=member_boards,
        upcoming=upcoming,
        overdue=overdue,
    )


@main_bp.route("/calendar")
@login_required
def calendar_view():
    cards = Card.query.filter(Card.due_date.isnot(None)).all()
    accessible = []
    for card in cards:
        if is_board_member(card.list.board, current_user):
            accessible.append(card)
    return render_template("main/calendar.html", cards=accessible)


def _build_digest_prompt(user, boards, upcoming, overdue):
    lines = [
        "You are an assistant that writes a clear daily digest email.",
        "Write in concise bullet points and sections with headings.",
        f"User: {user.name} ({user.email})",
        f"Boards: {len(boards)}",
        f"Upcoming: {len(upcoming)}",
        f"Past due: {len(overdue)}",
        "",
        "Upcoming items:",
    ]
    for card in upcoming[:10]:
        lines.append(f"- {card.title} (Board: {card.list.board.name}, Due: {card.due_date.isoformat()})")
    lines.append("")
    lines.append("Past due items:")
    for card in overdue[:10]:
        lines.append(f"- {card.title} (Board: {card.list.board.name}, Due: {card.due_date.isoformat()})")
    lines.append("")
    lines.append("Provide a short summary and a suggested focus for today.")
    return "\n".join(lines)


def _fallback_digest(user, boards, upcoming, overdue):
    def fmt_card(card):
        return f"- {card.title} (Board: {card.list.board.name}, Due: {card.due_date.isoformat()})"

    body = [
        f"Daily Digest for {user.name}",
        "",
        f"Boards: {len(boards)}",
        "",
        "Upcoming (next 7 days):",
    ]
    body.extend([fmt_card(c) for c in upcoming[:10]] or ["- None"])
    body.extend(["", "Past due:"])
    body.extend([fmt_card(c) for c in overdue[:10]] or ["- None"])
    body.append("")
    return "\n".join(body)


@main_bp.route("/preferences", methods=["POST"])
@login_required
def preferences():
    pref = current_user.notification_pref
    if not pref:
        pref = NotificationPreference(user_id=current_user.id)
        db.session.add(pref)
    pref.due_reminders = request.form.get("due_reminders") == "on"
    pref.ai_digest = request.form.get("ai_digest") == "on"
    db.session.commit()
    flash("Preferences updated.", "success")
    return redirect(url_for("main.settings"))


@main_bp.route("/settings")
@login_required
def settings():
    return render_template("main/settings.html")




@main_bp.route("/search")
@login_required
def search():
    query = request.args.get("q", "").strip()
    label_id = request.args.get("label_id", "").strip()
    board_id = request.args.get("board_id", "").strip()
    due_filter = request.args.get("due", "").strip()
    results = []
    labels = []
    boards = []
    if query:
        cards_query = Card.query.filter(
            or_(Card.title.ilike(f"%{query}%"), Card.description.ilike(f"%{query}%"))
        )
        if board_id.isdigit():
            cards_query = cards_query.join(List).filter(List.board_id == int(board_id))
        cards = cards_query.all()
        for card in cards:
            if is_board_member(card.list.board, current_user):
                if label_id.isdigit():
                    if not any(lbl.id == int(label_id) for lbl in card.labels):
                        continue
                if due_filter:
                    now = datetime.utcnow()
                    if due_filter == "overdue" and not (card.due_date and card.due_date < now):
                        continue
                    if due_filter == "upcoming" and not (card.due_date and card.due_date >= now):
                        continue
                    if due_filter == "due24" and not (
                        card.due_date and card.due_date >= now and card.due_date <= now + timedelta(days=1)
                    ):
                        continue
                results.append(card)
    boards = Board.query.filter(
        or_(Board.owner_id == current_user.id, Board.id.in_([m.board_id for m in current_user.board_memberships]))
    ).all()
    labels = Label.query.filter(Label.board_id.in_([b.id for b in boards])).all() if boards else []
    return render_template(
        "main/search.html",
        query=query,
        results=results,
        labels=labels,
        boards=boards,
        label_id=label_id,
        board_id=board_id,
        due_filter=due_filter,
    )


@main_bp.route("/realtime")
@login_required
def realtime_status():
    return render_template("main/realtime.html", active_connections=active_connections)


@main_bp.route("/reminders")
def reminders():
    token = request.args.get("token", "")
    if not token or token != current_app.config.get("REMINDER_TOKEN"):
        return jsonify({"error": "unauthorized"}), 401

    now, window = get_utc_window(days=1)
    cards = Card.query.filter(Card.due_date.isnot(None), Card.due_date <= window, Card.due_date >= now).all()

    sent = 0
    for card in cards:
        board = card.list.board
        recipients = [board.owner]
        for membership in board.members:
            recipients.append(membership.user)
        for user in recipients:
            pref = user.notification_pref
            if pref and not pref.due_reminders:
                continue
            body = (
                f"Reminder: '{card.title}' is due {card.due_date.isoformat()}\n"
                f"Board: {board.name}"
            )
            ok, _ = send_email(user.email, "Card due reminder", body)
            if ok:
                sent += 1

    return jsonify({"sent": sent, "cards": len(cards)})


@main_bp.route("/digests")
def digests():
    token = request.args.get("token", "")
    if not token or token != current_app.config.get("DIGEST_TOKEN"):
        return jsonify({"error": "unauthorized"}), 401

    now = datetime.utcnow()
    users = User.query.all()
    sent = 0
    for user in users:
        pref = user.notification_pref
        if not pref or not pref.ai_digest:
            continue
        owned = Board.query.filter_by(owner_id=user.id).all()
        member_ids = [m.board_id for m in user.board_memberships]
        member_boards = Board.query.filter(Board.id.in_(member_ids)).all() if member_ids else []
        boards = owned + [b for b in member_boards if b not in owned]
        upcoming = []
        overdue = []
        for board in boards:
            for lst in board.lists:
                for card in lst.cards:
                    if card.due_date:
                        if card.due_date < now:
                            overdue.append(card)
                        elif card.due_date <= now + timedelta(days=7):
                            upcoming.append(card)
        prompt = _build_digest_prompt(user, boards, upcoming, overdue)
        ai_text, error = generate_digest(prompt)
        body = ai_text or _fallback_digest(user, boards, upcoming, overdue)
        send_email(user.email, "Your daily board digest", body)
        sent += 1

    return jsonify({"sent": sent})
