from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import os
from flask import abort, current_app
from flask_login import current_user
from .models import Board, BoardMember, Setting, ActivityLog
from . import db


def is_board_member(board, user):
    if board.owner_id == user.id:
        return True
    return BoardMember.query.filter_by(board_id=board.id, user_id=user.id).first() is not None


def get_board_role(board, user):
    if user.is_admin:
        return "site_admin"
    if board.owner_id == user.id:
        return "owner"
    membership = BoardMember.query.filter_by(board_id=board.id, user_id=user.id).first()
    return membership.role if membership else None


def can_view(board, user):
    return get_board_role(board, user) is not None


def can_edit(board, user):
    return get_board_role(board, user) in {"site_admin", "owner", "admin", "member"}


def can_admin(board, user):
    return get_board_role(board, user) in {"site_admin", "owner", "admin"}


def require_board_access(board_id):
    board = Board.query.get_or_404(board_id)
    if not can_view(board, current_user):
        abort(403)
    return board


def get_timezone_name():
    return Setting.get("tz_name", "UTC") or "UTC"


def get_timezone():
    tz_name = get_timezone_name()
    try:
        return ZoneInfo(tz_name)
    except Exception:  # noqa: BLE001
        return timezone.utc


def parse_datetime(value):
    if not value:
        return None
    try:
        local_dt = datetime.fromisoformat(value)
    except ValueError:
        return None
    tz = get_timezone()
    local_dt = local_dt.replace(tzinfo=tz)
    utc_dt = local_dt.astimezone(timezone.utc).replace(tzinfo=None)
    return utc_dt


def get_local_now():
    tz = get_timezone()
    return datetime.now(tz)


def apply_tz_offset(dt_value):
    if not dt_value:
        return None
    tz = get_timezone()
    utc_dt = dt_value.replace(tzinfo=timezone.utc)
    local_dt = utc_dt.astimezone(tz).replace(tzinfo=None)
    return local_dt


def get_utc_window(days=1):
    tz = get_timezone()
    now_local = datetime.now(tz)
    window_local = now_local + timedelta(days=days)
    now_utc = now_local.astimezone(timezone.utc).replace(tzinfo=None)
    window_utc = window_local.astimezone(timezone.utc).replace(tzinfo=None)
    return now_utc, window_utc


def log_activity(action, board_id=None, user_id=None, details=None):
    log = ActivityLog(board_id=board_id, user_id=user_id, action=action, details=details)
    db.session.add(log)
    db.session.commit()


def is_allowed_file(filename):
    if not filename or "." not in filename:
        return False
    allowed = current_app.config.get("ALLOWED_EXTENSIONS", "")
    allowed_set = {ext.strip().lower() for ext in allowed.split(",") if ext.strip()}
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in allowed_set
