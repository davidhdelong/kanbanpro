from datetime import datetime
import os
import uuid
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, send_from_directory, current_app
from werkzeug.utils import secure_filename
from flask_login import login_required, current_user
from .. import db, csrf
from ..models import Board, List, Card, BoardMember, InviteToken, User, Label, Attachment, ActivityLog
from ..utils import (
    require_board_access,
    parse_datetime,
    is_board_member,
    can_edit,
    can_admin,
    can_view,
    log_activity,
    is_allowed_file,
)
from ..email import send_email
from ..realtime import emit_board_update


boards_bp = Blueprint("boards", __name__, url_prefix="/boards")


def _delete_card_files(card):
    upload_dir = current_app.config["UPLOAD_DIR"]
    for att in card.attachments:
        file_path = os.path.join(upload_dir, att.stored_name)
        if os.path.exists(file_path):
            os.remove(file_path)


@boards_bp.route("/create", methods=["POST"])
@login_required
def create_board():
    name = request.form.get("name", "").strip()
    if not name:
        flash("Board name required.", "danger")
        return redirect(url_for("main.dashboard"))
    board = Board(name=name, owner_id=current_user.id)
    db.session.add(board)
    db.session.commit()
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/<int:board_id>")
@login_required
def view_board(board_id):
    board = require_board_access(board_id)
    members = BoardMember.query.filter_by(board_id=board.id).all()
    labels = Label.query.filter_by(board_id=board.id).all()
    member_ids = {m.user_id for m in members}
    available_users = User.query.filter(User.id.not_in(member_ids)).order_by(User.email.asc()).all()
    activity_logs = ActivityLog.query.filter_by(board_id=board.id).order_by(ActivityLog.created_at.desc()).limit(20).all()
    role = "site_admin" if current_user.is_admin else ("owner" if board.owner_id == current_user.id else None)
    if not role:
        membership = BoardMember.query.filter_by(board_id=board.id, user_id=current_user.id).first()
        role = membership.role if membership else None
    return render_template(
        "boards/board.html",
        board=board,
        members=members,
        labels=labels,
        role=role,
        activity_logs=activity_logs,
        available_users=available_users,
    )


@boards_bp.route("/<int:board_id>/rename", methods=["POST"])
@login_required
def rename_board(board_id):
    board = require_board_access(board_id)
    if not can_admin(board, current_user):
        flash("Only the owner can rename the board.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    name = request.form.get("name", "").strip()
    if name:
        board.name = name
        db.session.commit()
        emit_board_update(board.id)
        log_activity("board_renamed", board_id=board.id, user_id=current_user.id, details=name)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/<int:board_id>/delete", methods=["POST"])
@login_required
def delete_board(board_id):
    board = require_board_access(board_id)
    if not can_admin(board, current_user):
        flash("Only the owner can delete the board.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    for lst in board.lists:
        for card in lst.cards:
            _delete_card_files(card)
    db.session.delete(board)
    db.session.commit()
    emit_board_update(board.id)
    log_activity("board_deleted", board_id=board.id, user_id=current_user.id)
    flash("Board deleted.", "success")
    return redirect(url_for("main.dashboard"))


@boards_bp.route("/<int:board_id>/lists", methods=["POST"])
@login_required
def add_list(board_id):
    board = require_board_access(board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to add lists.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    name = request.form.get("name", "").strip()
    if not name:
        flash("List name required.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    position = List.query.filter_by(board_id=board.id).count()
    new_list = List(name=name, board_id=board.id, position=position)
    db.session.add(new_list)
    db.session.commit()
    emit_board_update(board.id)
    log_activity("list_added", board_id=board.id, user_id=current_user.id, details=name)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/lists/<int:list_id>/rename", methods=["POST"])
@login_required
def rename_list(list_id):
    lst = List.query.get_or_404(list_id)
    board = require_board_access(lst.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to rename lists.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    name = request.form.get("name", "").strip()
    if name:
        lst.name = name
        db.session.commit()
        emit_board_update(board.id)
        log_activity("list_renamed", board_id=board.id, user_id=current_user.id, details=name)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/lists/<int:list_id>/delete", methods=["POST"])
@login_required
def delete_list(list_id):
    lst = List.query.get_or_404(list_id)
    board = require_board_access(lst.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to delete lists.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    db.session.delete(lst)
    db.session.commit()
    emit_board_update(board.id)
    log_activity("list_deleted", board_id=board.id, user_id=current_user.id, details=lst.name)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/lists/<int:list_id>/cards", methods=["POST"])
@login_required
def add_card(list_id):
    lst = List.query.get_or_404(list_id)
    board = require_board_access(lst.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to add cards.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    title = request.form.get("title", "").strip()
    if not title:
        flash("Card title required.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    description = request.form.get("description", "").strip()
    due_date = parse_datetime(request.form.get("due_date", ""))
    status = request.form.get("status", "todo")
    position = Card.query.filter_by(list_id=list_id).count()
    card = Card(title=title, description=description, due_date=due_date, status=status, list_id=list_id, position=position)
    db.session.add(card)
    db.session.commit()
    emit_board_update(board.id)
    log_activity("card_added", board_id=board.id, user_id=current_user.id, details=title)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/cards/<int:card_id>/update", methods=["POST"])
@login_required
def update_card(card_id):
    card = Card.query.get_or_404(card_id)
    board = require_board_access(card.list.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to update cards.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    card.title = request.form.get("title", card.title).strip() or card.title
    card.description = request.form.get("description", card.description)
    card.due_date = parse_datetime(request.form.get("due_date", ""))
    card.status = request.form.get("status", card.status)
    label_ids = request.form.getlist("label_ids")
    labels = Label.query.filter(Label.id.in_(label_ids), Label.board_id == board.id).all() if label_ids else []
    card.labels = labels
    db.session.commit()
    emit_board_update(board.id)
    log_activity("card_updated", board_id=board.id, user_id=current_user.id, details=card.title)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/cards/<int:card_id>/delete", methods=["POST"])
@login_required
def delete_card(card_id):
    card = Card.query.get_or_404(card_id)
    board = require_board_access(card.list.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to delete cards.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    _delete_card_files(card)
    db.session.delete(card)
    db.session.commit()
    emit_board_update(board.id)
    log_activity("card_deleted", board_id=board.id, user_id=current_user.id, details=card.title)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/<int:board_id>/invite", methods=["POST"])
@login_required
def invite_member(board_id):
    board = require_board_access(board_id)
    if not can_admin(board, current_user):
        flash("Only the owner can invite members.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    user_id = request.form.get("user_id", "").strip()
    if not user_id.isdigit():
        flash("Select a valid user.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    user = User.query.get(int(user_id))
    if not user:
        flash("User not found.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    if is_board_member(board, user):
        flash("User already on board.", "warning")
        return redirect(url_for("boards.view_board", board_id=board.id))
    member = BoardMember(board_id=board.id, user_id=user.id, role="member")
    db.session.add(member)
    db.session.commit()
    send_email(user.email, f"Board added: {board.name}", f"You were added to board '{board.name}'.")
    emit_board_update(board.id)
    log_activity("member_invited", board_id=board.id, user_id=current_user.id, details=user.email)
    flash("Invite sent.", "success")
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/invite/<token>")
@login_required
def accept_invite(token):
    invite = InviteToken.query.filter_by(token=token).first_or_404()
    if not invite.is_valid():
        flash("Invite invalid or expired.", "danger")
        return redirect(url_for("main.dashboard"))
    if invite.email != current_user.email:
        flash("Invite email does not match your account.", "danger")
        return redirect(url_for("main.dashboard"))
    if not is_board_member(invite.board, current_user):
        member = BoardMember(board_id=invite.board_id, user_id=current_user.id, role="member")
        db.session.add(member)
    invite.accepted = True
    db.session.commit()
    emit_board_update(invite.board_id)
    log_activity("member_joined", board_id=invite.board_id, user_id=current_user.id)
    flash("You joined the board.", "success")
    return redirect(url_for("boards.view_board", board_id=invite.board_id))


@boards_bp.route("/<int:board_id>/labels", methods=["POST"])
@login_required
def add_label(board_id):
    board = require_board_access(board_id)
    if not can_admin(board, current_user):
        flash("Only board admins can manage labels.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    name = request.form.get("name", "").strip()
    color = request.form.get("color", "#1b5fc1").strip()
    if not name:
        flash("Label name required.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    label = Label(board_id=board.id, name=name, color=color)
    db.session.add(label)
    db.session.commit()
    log_activity("label_added", board_id=board.id, user_id=current_user.id, details=name)
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/labels/<int:label_id>/delete", methods=["POST"])
@login_required
def delete_label(label_id):
    label = Label.query.get_or_404(label_id)
    board = require_board_access(label.board_id)
    if not can_admin(board, current_user):
        flash("Only board admins can manage labels.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    name = label.name
    db.session.delete(label)
    db.session.commit()
    log_activity("label_deleted", board_id=board.id, user_id=current_user.id, details=name)
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/members/<int:member_id>/role", methods=["POST"])
@login_required
def update_member_role(member_id):
    member = BoardMember.query.get_or_404(member_id)
    board = require_board_access(member.board_id)
    if not can_admin(board, current_user):
        flash("Only board admins can manage roles.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    role = request.form.get("role", "member")
    if role not in {"admin", "member", "viewer"}:
        flash("Invalid role.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    member.role = role
    db.session.commit()
    log_activity("member_role_updated", board_id=board.id, user_id=current_user.id, details=f"{member.user.email}:{role}")
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/members/<int:member_id>/remove", methods=["POST"])
@login_required
def remove_member(member_id):
    member = BoardMember.query.get_or_404(member_id)
    board = require_board_access(member.board_id)
    if not can_admin(board, current_user):
        flash("Only board admins can manage members.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    email = member.user.email
    db.session.delete(member)
    db.session.commit()
    log_activity("member_removed", board_id=board.id, user_id=current_user.id, details=email)
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/cards/<int:card_id>/attachments", methods=["POST"])
@login_required
def add_attachment(card_id):
    card = Card.query.get_or_404(card_id)
    board = require_board_access(card.list.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to add attachments.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    file = request.files.get("file")
    if not file or not file.filename:
        flash("File required.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    filename = secure_filename(file.filename)
    if not is_allowed_file(filename):
        flash("File type not allowed.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    stored_name = f"{uuid.uuid4().hex}_{filename}"
    upload_dir = current_app.config["UPLOAD_DIR"]
    file_path = os.path.join(upload_dir, stored_name)
    file.save(file_path)
    attachment = Attachment(
        card_id=card.id,
        uploaded_by=current_user.id,
        filename=filename,
        stored_name=stored_name,
        size=os.path.getsize(file_path),
    )
    db.session.add(attachment)
    db.session.commit()
    log_activity("attachment_added", board_id=board.id, user_id=current_user.id, details=filename)
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/attachments/<int:attachment_id>/download")
@login_required
def download_attachment(attachment_id):
    attachment = Attachment.query.get_or_404(attachment_id)
    board = require_board_access(attachment.card.list.board_id)
    if not can_view(board, current_user):
        return "", 403
    upload_dir = current_app.config["UPLOAD_DIR"]
    return send_from_directory(upload_dir, attachment.stored_name, as_attachment=True, download_name=attachment.filename)


@boards_bp.route("/attachments/<int:attachment_id>/delete", methods=["POST"])
@login_required
def delete_attachment(attachment_id):
    attachment = Attachment.query.get_or_404(attachment_id)
    board = require_board_access(attachment.card.list.board_id)
    if not can_edit(board, current_user):
        flash("You do not have permission to delete attachments.", "danger")
        return redirect(url_for("boards.view_board", board_id=board.id))
    upload_dir = current_app.config["UPLOAD_DIR"]
    file_path = os.path.join(upload_dir, attachment.stored_name)
    if os.path.exists(file_path):
        os.remove(file_path)
    filename = attachment.filename
    db.session.delete(attachment)
    db.session.commit()
    log_activity("attachment_deleted", board_id=board.id, user_id=current_user.id, details=filename)
    emit_board_update(board.id)
    return redirect(url_for("boards.view_board", board_id=board.id))


@boards_bp.route("/<int:board_id>/reorder", methods=["POST"])
@login_required
@csrf.exempt
def reorder(board_id):
    board = require_board_access(board_id)
    if not can_edit(board, current_user):
        return jsonify({"error": "forbidden"}), 403
    data = request.get_json(silent=True) or {}
    lists = data.get("lists", [])
    cards = data.get("cards", {})

    for idx, list_id in enumerate(lists):
        lst = List.query.get(list_id)
        if lst and lst.board_id == board.id:
            lst.position = idx

    for list_id, card_ids in cards.items():
        lst = List.query.get(int(list_id))
        if not lst or lst.board_id != board.id:
            continue
        for idx, card_id in enumerate(card_ids):
            card = Card.query.get(card_id)
            if card and card.list_id != lst.id:
                card.list_id = lst.id
            if card:
                card.position = idx

    db.session.commit()
    emit_board_update(board.id)
    log_activity("board_reordered", board_id=board.id, user_id=current_user.id)
    return jsonify({"status": "ok"})
