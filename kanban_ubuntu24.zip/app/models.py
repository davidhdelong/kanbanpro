import os
import uuid
from datetime import datetime, timedelta
from flask_login import UserMixin
from sqlalchemy import UniqueConstraint
from . import db, login_manager, bcrypt

card_labels = db.Table(
    "card_labels",
    db.Column("card_id", db.Integer, db.ForeignKey("card.id"), primary_key=True),
    db.Column("label_id", db.Integer, db.ForeignKey("label.id"), primary_key=True),
)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class Setting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.String(512), nullable=True)

    @staticmethod
    def get(key, default=None):
        setting = Setting.query.filter_by(key=key).first()
        if setting and setting.value is not None:
            return setting.value
        return default

    @staticmethod
    def set(key, value):
        setting = Setting.query.filter_by(key=key).first()
        if not setting:
            setting = Setting(key=key, value=value)
            db.session.add(setting)
        else:
            setting.value = value
        db.session.commit()

    @staticmethod
    def get_many(keys):
        settings = Setting.query.filter(Setting.key.in_(keys)).all()
        return {s.key: s.value for s in settings}


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    boards_owned = db.relationship("Board", backref="owner", lazy=True)

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode("utf-8")

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

    @property
    def is_active(self):
        return self.enabled


class Board(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    lists = db.relationship("List", backref="board", cascade="all, delete-orphan", order_by="List.position")


class BoardMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    board_id = db.Column(db.Integer, db.ForeignKey("board.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    role = db.Column(db.String(20), default="member")

    board = db.relationship("Board", backref=db.backref("members", cascade="all, delete-orphan"))
    user = db.relationship("User", backref=db.backref("board_memberships", cascade="all, delete-orphan"))

    __table_args__ = (UniqueConstraint("board_id", "user_id", name="uq_board_member"),)


class List(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    board_id = db.Column(db.Integer, db.ForeignKey("board.id"), nullable=False)
    position = db.Column(db.Integer, default=0)

    cards = db.relationship("Card", backref="list", cascade="all, delete-orphan", order_by="Card.position")


class Card(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    list_id = db.Column(db.Integer, db.ForeignKey("list.id"), nullable=False)
    position = db.Column(db.Integer, default=0)
    due_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    labels = db.relationship("Label", secondary=card_labels, backref="cards")
    attachments = db.relationship("Attachment", backref="card", cascade="all, delete-orphan")


class InviteToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(64), unique=True, nullable=False, default=lambda: uuid.uuid4().hex)
    email = db.Column(db.String(255), nullable=False)
    board_id = db.Column(db.Integer, db.ForeignKey("board.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(days=3))
    accepted = db.Column(db.Boolean, default=False)

    board = db.relationship("Board", backref=db.backref("invites", cascade="all, delete-orphan"))

    def is_valid(self):
        return not self.accepted and datetime.utcnow() <= self.expires_at


class ResetToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    token = db.Column(db.String(64), unique=True, nullable=False, default=lambda: uuid.uuid4().hex)
    code = db.Column(db.String(6), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(hours=1))
    used = db.Column(db.Boolean, default=False)

    user = db.relationship("User", backref=db.backref("reset_tokens", cascade="all, delete-orphan"))

    def is_valid(self):
        return not self.used and datetime.utcnow() <= self.expires_at


class EmailLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    to_email = db.Column(db.String(255), nullable=False)
    subject = db.Column(db.String(255), nullable=False)
    body = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    board_id = db.Column(db.Integer, db.ForeignKey("board.id"), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    action = db.Column(db.String(120), nullable=False)
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    board = db.relationship("Board", backref=db.backref("activity_logs", cascade="all, delete-orphan"))
    user = db.relationship("User", backref=db.backref("activity_logs", cascade="all, delete-orphan"))


class Label(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    board_id = db.Column(db.Integer, db.ForeignKey("board.id"), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    color = db.Column(db.String(7), default="#1b5fc1")

    board = db.relationship("Board", backref=db.backref("labels", cascade="all, delete-orphan"))


class Attachment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    card_id = db.Column(db.Integer, db.ForeignKey("card.id"), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    filename = db.Column(db.String(255), nullable=False)
    stored_name = db.Column(db.String(255), nullable=False)
    size = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    uploader = db.relationship("User", backref=db.backref("attachments", cascade="all, delete-orphan"))


class BackupLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    path = db.Column(db.String(512), nullable=False)
    status = db.Column(db.String(50), nullable=False)
    error = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class NotificationPreference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False)
    due_reminders = db.Column(db.Boolean, default=True)
    ai_digest = db.Column(db.Boolean, default=False)

    user = db.relationship("User", backref=db.backref("notification_pref", uselist=False, cascade="all, delete-orphan"))
