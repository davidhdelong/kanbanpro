import random
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from .. import db
from ..models import User, ResetToken, NotificationPreference
from ..email import send_email


auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


def _generate_code():
    return f"{random.randint(0, 999999):06d}"


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("auth/register.html")
        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
            return render_template("auth/register.html")

        is_first = User.query.count() == 0
        user = User(name=name, email=email, is_admin=is_first, enabled=True)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        pref = NotificationPreference(user_id=user.id, due_reminders=True)
        db.session.add(pref)
        db.session.commit()

        login_user(user)
        if is_first:
            flash("Admin account created.", "success")
        return redirect(url_for("main.dashboard"))

    return render_template("auth/register.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            flash("Invalid credentials.", "danger")
            return render_template("auth/login.html")
        if not user.enabled:
            flash("Account disabled. Contact admin.", "warning")
            return render_template("auth/login.html")
        login_user(user)
        return redirect(url_for("main.dashboard"))
    return render_template("auth/login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))


@auth_bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if not current_user.check_password(current_password):
            flash("Current password is incorrect.", "danger")
            return render_template("auth/change_password.html")
        if not new_password or new_password != confirm:
            flash("New passwords do not match.", "danger")
            return render_template("auth/change_password.html")
        current_user.set_password(new_password)
        db.session.commit()
        flash("Password updated.", "success")
        return redirect(url_for("main.settings"))
    return render_template("auth/change_password.html")


@auth_bp.route("/forgot", methods=["GET", "POST"])
def forgot():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            token = ResetToken(user_id=user.id, code=_generate_code())
            db.session.add(token)
            db.session.commit()
            reset_link = url_for("auth.reset", token=token.token, _external=True)
            body = (
                f"Your password reset code is: {token.code}\n"
                f"Reset link: {reset_link}\n"
                "This code expires in 1 hour."
            )
            send_email(user.email, "Password reset", body)
        flash("If the email exists, a reset code was sent.", "info")
        return redirect(url_for("auth.login"))
    return render_template("auth/forgot.html")


@auth_bp.route("/reset/<token>", methods=["GET", "POST"])
def reset(token):
    reset_token = ResetToken.query.filter_by(token=token).first()
    if not reset_token or not reset_token.is_valid():
        flash("Reset token invalid or expired.", "danger")
        return redirect(url_for("auth.forgot"))

    if request.method == "POST":
        code = request.form.get("code", "").strip()
        password = request.form.get("password", "")
        if code != reset_token.code:
            flash("Invalid code.", "danger")
            return render_template("auth/reset.html", token=token)
        if not password:
            flash("Password required.", "danger")
            return render_template("auth/reset.html", token=token)
        user = reset_token.user
        user.set_password(password)
        reset_token.used = True
        db.session.commit()
        flash("Password updated. Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/reset.html", token=token)
