(function () {
  const stored = localStorage.getItem("theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const initial = stored || "auto";
  const theme = initial === "auto" ? (prefersDark ? "dark" : "light") : initial;
  document.documentElement.setAttribute("data-bs-theme", theme);

  document.querySelectorAll("[data-theme]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const choice = btn.getAttribute("data-theme");
      const resolved = choice === "auto"
        ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
        : choice;
      document.documentElement.setAttribute("data-bs-theme", resolved);
      localStorage.setItem("theme", choice);
    });
  });
})();
