import asyncio
import socketio

sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins="*")
active_connections = 0


@sio.event
async def join_board(sid, data):  # noqa: ANN001
    board_id = data.get("board_id")
    if board_id is not None:
        await sio.enter_room(sid, f"board_{board_id}")


@sio.event
async def connect(sid, environ):  # noqa: ANN001
    global active_connections
    active_connections += 1


@sio.event
async def disconnect(sid):  # noqa: ANN001
    global active_connections
    active_connections = max(0, active_connections - 1)


def emit_board_update(board_id):
    try:
        asyncio.run(sio.emit("board_updated", {"board_id": board_id}, room=f"board_{board_id}"))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(
            sio.emit("board_updated", {"board_id": board_id}, room=f"board_{board_id}")
        )
        loop.close()
