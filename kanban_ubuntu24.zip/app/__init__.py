import os
import logging
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from flask import Flask
from dotenv import load_dotenv
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_wtf import CSRFProtect


db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
csrf = CSRFProtect()


def create_app():
    load_dotenv()
    app = Flask(__name__, instance_relative_config=True)

    # Ensure instance folder exists
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Failed to create instance directory: {exc}") from exc

    db_path = os.path.join(app.instance_path, "app.db")
    database_uri = f"sqlite:////{db_path}"

    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "change-me"),
        SQLALCHEMY_DATABASE_URI=database_uri,
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        REMINDER_TOKEN=os.getenv("REMINDER_TOKEN", ""),
        DIGEST_TOKEN=os.getenv("DIGEST_TOKEN", ""),
        APP_URL=os.getenv("APP_URL", "http://127.0.0.1:5000"),
        MAX_CONTENT_LENGTH=int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024 * 1024,
        ALLOWED_EXTENSIONS=os.getenv("ALLOWED_EXTENSIONS", "png,jpg,jpeg,pdf,txt,doc,docx,xlsx"),
        SMTP_HOST=os.getenv("SMTP_HOST", ""),
        SMTP_PORT=int(os.getenv("SMTP_PORT", "587")),
        SMTP_USER=os.getenv("SMTP_USER", ""),
        SMTP_PASS=os.getenv("SMTP_PASS", ""),
        SMTP_TLS=os.getenv("SMTP_TLS", "true").lower() == "true",
        SMTP_FROM=os.getenv("SMTP_FROM", "no-reply@example.com"),
    )

    upload_dir = os.path.join(app.instance_path, "uploads")
    os.makedirs(upload_dir, exist_ok=True)
    app.config["UPLOAD_DIR"] = upload_dir

    logging.basicConfig(level=logging.INFO)

    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)
    csrf.init_app(app)

    login_manager.login_view = "auth.login"

    from .auth.routes import auth_bp
    from .boards.routes import boards_bp
    from .admin.routes import admin_bp
    from .main.routes import main_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(boards_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(main_bp)

    with app.app_context():
        from . import models  # noqa: F401
        try:
            db.create_all()
        except SQLAlchemyError as exc:
            app.logger.error("Database initialization failed: %s", exc)
            raise
        try:
            result = db.session.execute(text("PRAGMA table_info(notification_preference)"))
            cols = {row[1] for row in result.fetchall()}
            if "ai_digest" not in cols:
                db.session.execute(text("ALTER TABLE notification_preference ADD COLUMN ai_digest BOOLEAN DEFAULT 0"))
                db.session.commit()
        except SQLAlchemyError as exc:
            app.logger.error("Database migration failed: %s", exc)
        try:
            result = db.session.execute(text("PRAGMA table_info(card)"))
            cols = {row[1] for row in result.fetchall()}
            if "status" not in cols:
                db.session.execute(text("ALTER TABLE card ADD COLUMN status VARCHAR(20) DEFAULT 'todo'"))
                db.session.commit()
        except SQLAlchemyError as exc:
            app.logger.error("Card migration failed: %s", exc)

    from .utils import apply_tz_offset
    app.add_template_filter(apply_tz_offset, name="localtime")

    @app.errorhandler(SQLAlchemyError)
    def handle_db_error(error):  # noqa: ANN001
        app.logger.error("Database error: %s", error)
        return "Database error occurred. Check logs.", 500

    return app
