import os
import shutil
import subprocess
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from .. import db
from ..models import User, Board, Setting, EmailLog, BackupLog, NotificationPreference, ActivityLog
from ..email import send_email, get_smtp_config
from ..utils import log_activity
from ..ai import test_connection
from zoneinfo import available_timezones


admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

COMMON_TIMEZONES = [
    "UTC",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "America/Phoenix",
    "America/Anchorage",
    "Pacific/Honolulu",
    "Europe/London",
    "Europe/Paris",
    "Europe/Berlin",
    "Europe/Madrid",
    "Europe/Rome",
    "Asia/Tokyo",
    "Asia/Seoul",
    "Asia/Singapore",
    "Asia/Kolkata",
    "Australia/Sydney",
    "Australia/Melbourne",
]


def apply_cron_jobs(
    reminder_enabled,
    reminder_cron,
    backup_enabled,
    backup_cron,
    backup_path,
    retention_days,
    cleanup_enabled,
    cleanup_cron,
    digest_enabled,
    digest_cron,
    app_url,
    digest_token,
):
    marker_begin = "# BEGIN KANBAN"
    marker_end = "# END KANBAN"

    lines = []
    if reminder_enabled:
        lines.append(f"{reminder_cron} /home/server/scripts/run_reminders.sh")
    if backup_enabled:
        lines.append(
            f"{backup_cron} /home/server/.venv/bin/python /home/server/scripts/backup_db.py "
            f"--dest {backup_path} --retention-days {retention_days}"
        )
    if cleanup_enabled:
        lines.append(f"{cleanup_cron} /home/server/.venv/bin/python /home/server/scripts/cleanup_db.py")
    if digest_enabled and digest_token:
        lines.append(f"{digest_cron} /usr/bin/curl -fsS {app_url}/digests?token={digest_token}")

    result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    current = result.stdout if result.returncode == 0 else ""

    filtered = []
    in_block = False
    for line in current.splitlines():
        if line.strip() == marker_begin:
            in_block = True
            continue
        if line.strip() == marker_end:
            in_block = False
            continue
        if not in_block:
            filtered.append(line)

    if lines:
        filtered.extend([marker_begin, *lines, marker_end])

    new_content = "\n".join([line for line in filtered if line.strip() != ""]).strip() + "\n"
    subprocess.run(["crontab", "-"], input=new_content, text=True, check=True)


def run_backup_now(backup_path, retention_days):
    os.makedirs(backup_path, exist_ok=True)
    db_path = os.path.join(current_app.instance_path, "app.db")
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup_file = os.path.join(backup_path, f"app_{timestamp}.db")

    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database not found: {db_path}")

    shutil.copy2(db_path, backup_file)

    cutoff = datetime.utcnow() - timedelta(days=retention_days)
    for name in os.listdir(backup_path):
        if not name.startswith("app_") or not name.endswith(".db"):
            continue
        path = os.path.join(backup_path, name)
        mtime = datetime.utcfromtimestamp(os.path.getmtime(path))
        if mtime < cutoff:
            try:
                os.remove(path)
            except OSError:
                pass

    return backup_file


def admin_required():
    if not current_user.is_admin:
        flash("Admin access required.", "danger")
        return False
    return True


@admin_bp.route("/")
@login_required
def dashboard():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    user_count = User.query.count()
    board_count = Board.query.count()
    email_count = EmailLog.query.count()
    return render_template("admin/dashboard.html", user_count=user_count, board_count=board_count, email_count=email_count)


@admin_bp.route("/users")
@login_required
def users():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=users)


@admin_bp.route("/users/create", methods=["POST"])
@login_required
def create_user():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    is_admin = request.form.get("is_admin") == "on"
    enabled = request.form.get("enabled") == "on"

    if not name or not email or not password:
        flash("Name, email, and password are required.", "danger")
        return redirect(url_for("admin.users"))
    if User.query.filter_by(email=email).first():
        flash("Email already exists.", "danger")
        return redirect(url_for("admin.users"))

    user = User(name=name, email=email, is_admin=is_admin, enabled=enabled)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    pref = NotificationPreference(user_id=user.id, due_reminders=True)
    db.session.add(pref)
    db.session.commit()
    flash("User created.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/toggle", methods=["POST"])
@login_required
def toggle_user(user_id):
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Cannot disable yourself.", "warning")
        return redirect(url_for("admin.users"))
    user.enabled = not user.enabled
    db.session.commit()
    log_activity("admin_user_toggle", user_id=current_user.id, details=f"{user.email}:{user.enabled}")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/admin", methods=["POST"])
@login_required
def toggle_admin(user_id):
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Cannot change your own admin status.", "warning")
        return redirect(url_for("admin.users"))
    user.is_admin = not user.is_admin
    db.session.commit()
    log_activity("admin_user_role_toggle", user_id=current_user.id, details=f"{user.email}:{user.is_admin}")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/delete", methods=["POST"])
@login_required
def delete_user(user_id):
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Cannot delete yourself.", "warning")
        return redirect(url_for("admin.users"))
    Board.query.filter_by(owner_id=user.id).update({"owner_id": current_user.id})
    db.session.flush()
    email = user.email
    db.session.delete(user)
    db.session.commit()
    log_activity("admin_user_deleted", user_id=current_user.id, details=email)
    flash("User deleted.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/boards")
@login_required
def boards():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    boards = Board.query.order_by(Board.created_at.desc()).all()
    users = User.query.order_by(User.email.asc()).all()
    return render_template("admin/boards.html", boards=boards, users=users)


@admin_bp.route("/boards/<int:board_id>/delete", methods=["POST"])
@login_required
def delete_board(board_id):
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    board = Board.query.get_or_404(board_id)
    db.session.delete(board)
    db.session.commit()
    log_activity("admin_board_deleted", user_id=current_user.id, details=board.name)
    return redirect(url_for("admin.boards"))


@admin_bp.route("/boards/<int:board_id>/reassign", methods=["POST"])
@login_required
def reassign_board(board_id):
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    board = Board.query.get_or_404(board_id)
    new_owner_id = request.form.get("owner_id", "").strip()
    if not new_owner_id.isdigit():
        flash("Select a valid owner.", "danger")
        return redirect(url_for("admin.boards"))
    new_owner = User.query.get(int(new_owner_id))
    if not new_owner:
        flash("User not found.", "danger")
        return redirect(url_for("admin.boards"))
    board.owner_id = new_owner.id
    db.session.commit()
    log_activity("admin_board_reassigned", user_id=current_user.id, details=f"{board.name} -> {new_owner.email}")
    flash("Board reassigned.", "success")
    return redirect(url_for("admin.boards"))


@admin_bp.route("/smtp", methods=["GET", "POST"])
@login_required
def smtp():
    if not admin_required():
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        Setting.set("smtp_host", request.form.get("smtp_host", ""))
        Setting.set("smtp_port", request.form.get("smtp_port", ""))
        Setting.set("smtp_user", request.form.get("smtp_user", ""))
        Setting.set("smtp_pass", request.form.get("smtp_pass", ""))
        Setting.set("smtp_tls", "true" if request.form.get("smtp_tls") == "on" else "false")
        Setting.set("smtp_from", request.form.get("smtp_from", ""))
        flash("SMTP settings updated.", "success")
        log_activity("admin_smtp_updated", user_id=current_user.id)
        return redirect(url_for("admin.smtp"))

    config = get_smtp_config()
    return render_template("admin/smtp.html", config=config)


@admin_bp.route("/timezone", methods=["GET", "POST"])
@login_required
def timezone():
    if not admin_required():
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        tz_name = request.form.get("tz_name", "UTC")
        if tz_name in available_timezones():
            Setting.set("tz_name", tz_name)
            flash("Timezone updated.", "success")
        else:
            flash("Invalid timezone.", "danger")
        return redirect(url_for("admin.timezone"))

    current_tz = Setting.get("tz_name", "UTC")
    return render_template("admin/timezone.html", current_tz=current_tz, timezones=COMMON_TIMEZONES)


@admin_bp.route("/maintenance", methods=["GET", "POST"])
@login_required
def maintenance():
    if not admin_required():
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        reminder_enabled = request.form.get("reminder_enabled") == "on"
        reminder_cron = request.form.get("reminder_cron", "0 * * * *").strip() or "0 * * * *"
        backup_enabled = request.form.get("backup_enabled") == "on"
        backup_cron = request.form.get("backup_cron", "0 2 * * *").strip() or "0 2 * * *"
        backup_path = request.form.get("backup_path", "/home/server/backups").strip() or "/home/server/backups"
        retention_days = request.form.get("retention_days", "7").strip() or "7"
        cleanup_enabled = request.form.get("cleanup_enabled") == "on"
        cleanup_cron = request.form.get("cleanup_cron", "30 2 * * *").strip() or "30 2 * * *"
        cleanup_retention_days = request.form.get("cleanup_retention_days", "30").strip() or "30"
        digest_enabled = request.form.get("digest_enabled") == "on"
        digest_cron = request.form.get("digest_cron", "0 8 * * *").strip() or "0 8 * * *"

        Setting.set("reminder_enabled", "true" if reminder_enabled else "false")
        Setting.set("reminder_cron", reminder_cron)
        Setting.set("backup_enabled", "true" if backup_enabled else "false")
        Setting.set("backup_cron", backup_cron)
        Setting.set("backup_path", backup_path)
        Setting.set("backup_retention_days", retention_days)
        Setting.set("cleanup_enabled", "true" if cleanup_enabled else "false")
        Setting.set("cleanup_cron", cleanup_cron)
        Setting.set("cleanup_retention_days", cleanup_retention_days)
        Setting.set("digest_enabled", "true" if digest_enabled else "false")
        Setting.set("digest_cron", digest_cron)

        try:
            apply_cron_jobs(
                reminder_enabled,
                reminder_cron,
                backup_enabled,
                backup_cron,
                backup_path,
                retention_days,
                cleanup_enabled,
                cleanup_cron,
                digest_enabled,
                digest_cron,
                current_app.config.get("APP_URL"),
                current_app.config.get("DIGEST_TOKEN"),
            )
            flash("Maintenance schedules applied.", "success")
            log_activity("admin_maintenance_updated", user_id=current_user.id)
        except OSError as exc:
            flash(f"Saved settings but failed to apply cron: {exc}", "warning")

        return redirect(url_for("admin.maintenance"))

    reminder_enabled = Setting.get("reminder_enabled", "false") == "true"
    reminder_cron = Setting.get("reminder_cron", "0 * * * *")
    backup_enabled = Setting.get("backup_enabled", "false") == "true"
    backup_cron = Setting.get("backup_cron", "0 2 * * *")
    backup_path = Setting.get("backup_path", "/home/server/backups")
    retention_days = Setting.get("backup_retention_days", "7")
    cleanup_enabled = Setting.get("cleanup_enabled", "false") == "true"
    cleanup_cron = Setting.get("cleanup_cron", "30 2 * * *")
    cleanup_retention_days = Setting.get("cleanup_retention_days", "30")

    return render_template(
        "admin/maintenance.html",
        reminder_enabled=reminder_enabled,
        reminder_cron=reminder_cron,
        backup_enabled=backup_enabled,
        backup_cron=backup_cron,
        backup_path=backup_path,
        retention_days=retention_days,
        cleanup_enabled=cleanup_enabled,
        cleanup_cron=cleanup_cron,
        cleanup_retention_days=cleanup_retention_days,
        digest_enabled=Setting.get("digest_enabled", "false") == "true",
        digest_cron=Setting.get("digest_cron", "0 8 * * *"),
    )


@admin_bp.route("/maintenance/backup", methods=["POST"])
@login_required
def maintenance_backup():
    if not admin_required():
        return redirect(url_for("main.dashboard"))

    backup_path = Setting.get("backup_path", "/home/server/backups")
    retention_days_value = Setting.get("backup_retention_days", "7")
    try:
        retention_days = int(retention_days_value)
    except (TypeError, ValueError):
        retention_days = 7

    status = "success"
    error = None
    backup_file = ""
    try:
        backup_file = run_backup_now(backup_path, retention_days)
        flash("Backup completed.", "success")
        log_activity("admin_backup_run", user_id=current_user.id, details=backup_file)
    except Exception as exc:  # noqa: BLE001
        status = "failed"
        error = str(exc)
        flash(f"Backup failed: {error}", "danger")

    log = BackupLog(path=backup_file or backup_path, status=status, error=error)
    db.session.add(log)
    db.session.commit()

    return redirect(url_for("admin.maintenance"))




@admin_bp.route("/smtp/test", methods=["POST"])
@login_required
def smtp_test():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    email = request.form.get("email", "").strip()
    if not email:
        flash("Email required.", "danger")
        return redirect(url_for("admin.smtp"))
    ok, error = send_email(email, "SMTP test", "This is a test email.")
    if ok:
        flash("Test email sent.", "success")
    else:
        flash(f"SMTP failed: {error}", "danger")
    return redirect(url_for("admin.smtp"))


@admin_bp.route("/emails")
@login_required
def emails():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    logs = EmailLog.query.order_by(EmailLog.created_at.desc()).limit(200).all()
    return render_template("admin/emails.html", logs=logs)


@admin_bp.route("/activity")
@login_required
def activity():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    logs = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(200).all()
    return render_template("admin/activity.html", logs=logs)


@admin_bp.route("/ai", methods=["GET", "POST"])
@login_required
def ai_settings():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        Setting.set("ai_enabled", "true" if request.form.get("ai_enabled") == "on" else "false")
        Setting.set("ai_api_key", request.form.get("ai_api_key", "").strip())
        Setting.set("ai_base_url", request.form.get("ai_base_url", "").strip())
        Setting.set("ai_model", request.form.get("ai_model", "").strip())
        Setting.set("ai_ignore_ssl", "true" if request.form.get("ai_ignore_ssl") == "on" else "false")
        log_activity("admin_ai_updated", user_id=current_user.id)
        flash("AI settings updated.", "success")
        return redirect(url_for("admin.ai_settings"))
    config = {
        "ai_enabled": Setting.get("ai_enabled", "false") == "true",
        "ai_api_key": Setting.get("ai_api_key", ""),
        "ai_base_url": Setting.get("ai_base_url", "https://api.anthropic.com"),
        "ai_model": Setting.get("ai_model", "claude-3-haiku-20240307"),
        "ai_ignore_ssl": Setting.get("ai_ignore_ssl", "false") == "true",
    }
    return render_template("admin/ai.html", config=config)


@admin_bp.route("/ai/test", methods=["POST"])
@login_required
def ai_test():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    text, error = test_connection()
    if error:
        flash(f"AI test failed: {error}", "danger")
    else:
        flash(f"AI test succeeded: {text}", "success")
    return redirect(url_for("admin.ai_settings"))




@admin_bp.route("/backups")
@login_required
def backups():
    if not admin_required():
        return redirect(url_for("main.dashboard"))
    logs = BackupLog.query.order_by(BackupLog.created_at.desc()).limit(200).all()
    return render_template("admin/backups.html", logs=logs)
